create definer = root@localhost view customersdetails as
select `supermarket`.`customer`.`CardID`           AS `CardID`,
       `supermarket`.`customer`.`Bonuspoints`      AS `Bonuspoints`,
       `supermarket`.`customer`.`Numberofchildren` AS `Numberofchildren`,
       `supermarket`.`customer`.`Fullname`         AS `Fullname`,
       `supermarket`.`customer`.`Maritalstatus`    AS `Maritalstatus`,
       `supermarket`.`customer`.`StoreID`          AS `StoreID`,
       `supermarket`.`customer`.`BirthDate`        AS `BirthDate`
from `supermarket`.`customer`
order by `supermarket`.`customer`.`CardID`;

