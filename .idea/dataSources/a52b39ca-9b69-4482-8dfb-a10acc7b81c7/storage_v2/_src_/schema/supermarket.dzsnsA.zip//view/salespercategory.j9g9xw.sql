create definer = root@localhost view salespercategory as
select `supermarket`.`customer_transaction`.`StoreID` AS `StoreID`,
       `supermarket`.`product`.`Kind`                 AS `Kind`,
       count(0)                                       AS `totalProductsSold`
from ((`supermarket`.`customer_transaction` join `supermarket`.`product_bought_by` on ((
        `supermarket`.`customer_transaction`.`TransactionID` = `supermarket`.`product_bought_by`.`TransactionID`)))
         join `supermarket`.`product`
              on ((`supermarket`.`product_bought_by`.`Barcode` = `supermarket`.`product`.`Barcode`)))
group by `supermarket`.`customer_transaction`.`StoreID`, `supermarket`.`product`.`Kind`
order by `supermarket`.`customer_transaction`.`StoreID`;

